<?php
// Powered by Freesite.by
include dirname(__FILE__).'/sitepro/index.php';
?>