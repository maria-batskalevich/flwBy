<!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Contact</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=992" />
		<meta name="description" content="" />
	<meta name="keywords" content="тюльпаны,тюльпаны оптом,тюльпаны в минске,тюльпаны к 8 марта,тюльпаны москва,голландские тюльпаны" />
	<!-- Facebook Open Graph -->
	<meta name="og:title" content="Contact" />
	<meta name="og:description" content="" />
	<meta name="og:image" content="" />
	<meta name="og:type" content="article" />
	<meta name="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20180125120040" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20180125120041" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1517239756" rel="stylesheet" type="text/css" />
	<link href="css/5.css?ts=1517239756" rel="stylesheet" type="text/css" />
	{{ga_code}}<link rel="shortcut icon" href="/gallery/rose (1)-ts1517236468.png" type="image/png" /><meta name="google-site-verification" content="" />
	<script type="text/javascript">var currLang = '';</script>	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->
</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance20" class="wb_element wb-menu"><ul class="hmenu"><li><a href="%D0%93%D0%BB%D0%B0%D0%B2%D0%BD%D0%B0%D1%8F/" target="_self">Главная</a></li><li><a href="about/" target="_self">О нас</a></li><li><a href="catalog/" target="_self">Каталог</a></li><li class="active"><a href="contacts/" target="_self">Контакты</a></li></ul><div class="clearfix"></div></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance22" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">Контакты</h5></div><div id="wb_element_instance23" class="wb_element" style=" line-height: normal;"><h3 class="wb-stl-heading3">ИП Бацкалевич МН, УНП 291340865</h3>

<h3 class="wb-stl-heading3"> </h3>

<h3 class="wb-stl-heading3"><strong>Наш адрес:</strong></h3>

<h3 class="wb-stl-heading3">Республика Беларусь, Брестская область, г. Ивацевичи, ул. Славянская</h3>

<p> </p>

<h3 class="wb-stl-heading3"><strong>Тел.: </strong><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;">+375 29 277 75 72  </span></span></span></span></span></span></span></span></span></span></span></span></span></span></span>Viber/WhatsApp</h3>

<h2 class="wb-stl-heading2"> </h2>
</div><div id="wb_element_instance25" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(5);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance25");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance25").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div><div class="wb_cont_outer"><div id="wb_element_instance24" class="wb_element wb-map"><div style="background: rgba(0,0,0,0.38); position: absolute; top: 0; left: 0; width: 100%; height: 100%;"><div style="font-size: 24px; width: 100%; color: #c00; padding: 0 20%; text-align: center; display: inline-block; vertical-align: middle;">Get API Key from <a style="display: inline-block; max-width: 100%; word-break: break-all; color: #fff;" target="_blank" href="https://developers.google.com/maps/documentation/javascript/get-api-key">https://developers.google.com/maps/documentation/javascript/get-api-key</a></div><div style="vertical-align: middle; height: 100%; display: inline-block;"></div></div><script type="text/javascript">
				(function() {
					var resizeFunc = function() {
						var elem = $("#wb_element_instance24");
						var w = elem.width(), h = elem.height();
						elem.find("div > div:first").css("zoom", Math.max(0.5, Math.min(1, ((w * h) / 120000))));
					};
					$(window).on("resize", resizeFunc);
					resizeFunc();
				})();
			</script></div></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 162px;"><div id="wb_element_instance21" class="wb_element wb_element_picture"><img alt="gallery/7902d102dbdb04b8f94c90cbe9b959e7.lock" src="gallery_gen/aef30f6db43c81496b03b103aba3d4cc.png"></div><div id="wb_element_instance26" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
